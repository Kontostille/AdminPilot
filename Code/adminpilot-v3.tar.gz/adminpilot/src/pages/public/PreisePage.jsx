import { SEOHead, TrustBar, DisclaimerBanner } from '../../components/shared/index.jsx';
import Button from '../../components/shared/Button.jsx';
import { Link } from '../../utils/router.jsx';
import { useState } from 'react';

export default function PreisePage() {
  const [faqOpen, setFaqOpen] = useState(null);
  const faqs = [
    { q: 'Wann muss ich bezahlen?', a: 'Erst nach der KI-Analyse und Antragstellung. Der Leistungscheck ist komplett kostenlos und unverbindlich.' },
    { q: 'Was, wenn mein Antrag abgelehnt wird?', a: 'Die Servicegebühr deckt die Erstellung und Einreichung des Antrags ab. Bei einer Ablehnung durch die Behörde können wir Sie bei einem Widerspruch unterstützen.' },
    { q: 'Gibt es ein Abo oder versteckte Kosten?', a: 'Nein. Die Gebühr ist einmalig pro Antrag. Kein Abo, keine Folgekosten, keine versteckten Gebühren.' },
    { q: 'Kann ich mehrere Leistungen gleichzeitig beantragen?', a: 'Ja. Jede Leistung wird separat bearbeitet und berechnet. Bei mehreren Anträgen sehen Sie die Kosten vorab transparent aufgeschlüsselt.' },
  ];

  return (
    <>
      <SEOHead title="Preise" description="Einmalige Servicegebühr pro Antrag. Kein Abo. Transparent und fair. Kostenloser Leistungscheck inklusive." keywords={['AdminPilot Kosten', 'AdminPilot Preise']} />

      <section className="section" style={{ background: '#FFF' }}>
        <div className="container" style={{ maxWidth: 'var(--max-width-narrow)', textAlign: 'center' }}>
          <p style={{ fontSize: 'var(--text-sm)', color: 'var(--ap-sage)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 'var(--space-4)' }}>Transparent & fair</p>
          <h1 style={{ marginBottom: 'var(--space-4)' }}>Einmalig. Kein Abo.</h1>
          <p style={{ fontSize: 'var(--text-lg)', color: 'var(--color-text-muted)', maxWidth: 500, margin: '0 auto var(--space-10)' }}>
            Sie zahlen nur, wenn Sie sich für einen Antrag entscheiden. Der Leistungscheck ist immer kostenlos.
          </p>

          {/* Pricing Card */}
          <div style={{
            maxWidth: 420, margin: '0 auto',
            background: 'var(--color-bg)', borderRadius: 'var(--radius-xl)',
            border: '2px solid var(--ap-dark)', overflow: 'hidden',
          }}>
            <div style={{ background: 'var(--ap-dark)', color: '#FFF', padding: 'var(--space-5) var(--space-6)' }}>
              <div style={{ fontSize: 'var(--text-sm)', color: 'var(--ap-mint)', fontWeight: 500 }}>Servicegebühr pro Antrag</div>
            </div>
            <div style={{ padding: 'var(--space-8) var(--space-6)' }}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 4 }}>
                <span style={{ fontSize: 'var(--text-5xl)', fontWeight: 700, color: 'var(--ap-dark)', fontFamily: 'var(--font-mono)' }}>150–250</span>
                <span style={{ fontSize: 'var(--text-xl)', color: 'var(--ap-sage)' }}>€</span>
              </div>
              <p style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', marginTop: 'var(--space-2)' }}>einmalig · je nach Leistungstyp</p>

              <div style={{ borderTop: '1px solid var(--color-border)', marginTop: 'var(--space-6)', paddingTop: 'var(--space-6)' }}>
                {[
                  'Kostenloser Leistungscheck',
                  'KI-Analyse Ihrer Dokumente',
                  'Vollständige Antragserstellung',
                  'Digitale Signatur & Einreichung',
                  'Status-Tracking per E-Mail',
                  'Kein Abo – einmalige Zahlung',
                ].map((item, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
                    padding: 'var(--space-2) 0', fontSize: 'var(--text-sm)',
                  }}>
                    <span style={{ color: 'var(--ap-dark)', fontWeight: 700, fontSize: 16 }}>✓</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              <Button variant="primary" fullWidth to="/leistungscheck" style={{ marginTop: 'var(--space-6)' }}>
                Kostenlos Anspruch prüfen →
              </Button>
            </div>
          </div>

          {/* Vergleich */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)',
            marginTop: 'var(--space-12)', maxWidth: 500, margin: 'var(--space-12) auto 0',
          }}>
            <div style={{ padding: 'var(--space-5)', background: 'var(--color-bg)', borderRadius: 'var(--radius-lg)', textAlign: 'center' }}>
              <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Anwalt / Berater</div>
              <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 700, color: 'var(--color-text)', marginTop: 'var(--space-2)' }}>150–300 €/Std.</div>
              <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginTop: 4 }}>+ mehrere Termine nötig</div>
            </div>
            <div style={{ padding: 'var(--space-5)', background: 'var(--ap-dark)', borderRadius: 'var(--radius-lg)', textAlign: 'center', color: '#FFF' }}>
              <div style={{ fontSize: 'var(--text-xs)', color: 'var(--ap-mint)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em' }}>AdminPilot</div>
              <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 700, color: 'var(--ap-gold)', marginTop: 'var(--space-2)' }}>150–250 € einmalig</div>
              <div style={{ fontSize: 'var(--text-xs)', color: 'var(--ap-mint)', marginTop: 4 }}>Alles inklusive, 10 Min.</div>
            </div>
          </div>
        </div>
      </section>

      <TrustBar />

      {/* FAQ */}
      <section className="section" style={{ background: 'var(--color-bg)' }}>
        <div className="container" style={{ maxWidth: 'var(--max-width-narrow)' }}>
          <h2 style={{ textAlign: 'center', marginBottom: 'var(--space-8)' }}>Fragen zu den Kosten</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
            {faqs.map((faq, i) => (
              <div key={i} style={{ background: '#FFF', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', overflow: 'hidden' }}>
                <button onClick={() => setFaqOpen(faqOpen === i ? null : i)} style={{
                  width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: 'var(--space-4) var(--space-5)', background: 'none', border: 'none', cursor: 'pointer',
                  fontFamily: 'var(--font-body)', fontSize: 'var(--text-base)', fontWeight: 600, color: 'var(--ap-dark)', textAlign: 'left',
                }}>
                  {faq.q}
                  <span style={{ fontSize: 18, color: 'var(--ap-sage)', transition: 'transform 0.15s', transform: faqOpen === i ? 'rotate(45deg)' : 'rotate(0)' }}>+</span>
                </button>
                {faqOpen === i && (
                  <div style={{ padding: '0 var(--space-5) var(--space-4)', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', lineHeight: 1.7 }}>{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="section"><div className="container" style={{ maxWidth: 'var(--max-width-narrow)', textAlign: 'center' }}>
        <h2 style={{ marginBottom: 'var(--space-4)' }}>Bereit?</h2>
        <p style={{ color: 'var(--color-text-muted)', marginBottom: 'var(--space-6)' }}>Der Leistungscheck ist kostenlos und unverbindlich.</p>
        <Button variant="primary" size="large" to="/leistungscheck">Jetzt kostenlos prüfen →</Button>
      </div></div>
    </>
  );
}
